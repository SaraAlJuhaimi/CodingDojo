const express = require("express");
const flash = require('express-flash');
var session = require("express-session")
var bodyParser = require('body-parser');
var mongoose = require("mongoose");
const app = express();
app.listen(8000, function () { })
app.use(flash());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: "secretkey",
    resave: true,
    saveUninitialized: true
}));
app.use(express.json());

//Database
mongoose.connect("mongodb://localhost/1955_db");
require("./server/config/mongoose.js");

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname + '/public'));

require('./server/config/routes.js')(app)




