const mongoose = require('mongoose');
var UserSchema = new mongoose.Schema({
    name: { type: String, required: [true, "name field must not be blank"] }
}, { timestamps: true })

mongoose.model('User', UserSchema);
