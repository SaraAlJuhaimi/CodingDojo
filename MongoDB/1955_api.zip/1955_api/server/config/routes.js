var methods = require("../controllers/users.js");
module.exports = function (app) {
    app.get('/', methods.find_all)
    app.get('/new/:name/', methods.add)
    app.get('/remove/:name/', methods.remove)
    app.get('/:name', methods.find)
}