const mongoose = require('mongoose');
var User = mongoose.model("User");

module.exports = {
    find_all: function(req, res) {
        User.find()
        .then(data => res.json(data))
        .catch(err => res.json(err));
    },
    add: function(req, res) {
    	const user = new User();
        user.name = req.params.name;
        user.save()
        .then(res.redirect('/'))
        .catch(err => res.json(err));
    },
    remove: function(req, res) {
    	User.deleteOne({name: req.params.name})
            .then(res.redirect('/'))
            .catch(err => res.json(err));
    },
    find: function(req, res) {
    	User.findOne({name: req.params.name})
        .then(data => res.json(data))
        .catch(err => res.json(err));
    }
    
};